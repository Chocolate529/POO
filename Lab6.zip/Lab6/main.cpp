#include "ui.h"
#include "teste.h"
int main() {
    Teste::runTests();
    MasinaRepo repo;
    MasinaService service{repo};
    MasinaUI ui{service};
    ui.run();
}
